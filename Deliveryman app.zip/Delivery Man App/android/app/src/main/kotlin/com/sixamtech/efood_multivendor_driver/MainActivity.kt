package com.sixamtech.sixam_mart_delivery_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
